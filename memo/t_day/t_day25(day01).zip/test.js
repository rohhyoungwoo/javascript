console.log("안녕하세요");
console.log("hello");
